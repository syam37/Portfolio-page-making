<?php
//include auth_session.php file on all user panel pages
include("auth_session.php");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Dashboard - Client area</title>
    <link rel="stylesheet" href="dash.css" />
</head>
<body>
    <div class="form">
        <h3>Hey, <?php echo $_SESSION['username']; ?>!</h3>
        <h3>You are in user dashboard page.</h3>
        <a href="logout.php">Logout</a>
        <a href="indexo.html">ENTER</a>
    </div>
</body>
</html>
