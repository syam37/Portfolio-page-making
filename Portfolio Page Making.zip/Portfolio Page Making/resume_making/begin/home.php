
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Image Upload</title>
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="stylesheet" href="certi/css/certificate.css" />
<title>Home</title>

<style>
.login-box{
    height: 20px;
    
}
</style>
</head>
<body>
	<center>
		<h1 style="padding:20px;color:#6e716ead;font-family:verdana;font-size:30px">Image Uploading</h1>
		<table style="width:600px">
			<form action="" method="post" enctype="multipart/form-data">
			 <div class="login-box">
				<tr><td>Name</td><td><input type="text" name="name" required/></td></tr>	
				<tr><td>Image</td><td><input type="file" name="image" size="40" required/></td></tr>
				<tr><td>Description</td><td><input type="text" name="description" required/></td></tr>
				<tr><td><input type="submit" value="upload" name="upload" accept="image/jpg,image/jpeg,image/png"  /></td><td><a href="indexstore.html">Back</a></td></tr>
			 </div> 
            </form>
		</table>
	</center>
</body>
</html>
<?php
    $connection=mysqli_connect("localhost:3306","root","");
    $db=mysqli_select_db($connection,'loginsystem');
    if(isset($_POST['upload']))
    {
        $name=$_POST['name'];
        $file = addslashes(file_get_contents($_FILES["image"]["tmp_name"]));
        $description=$_POST['description'];
        $query="INSERT INTO `imageupload`(`name`,`image`,`description`) VALUES ('$name','$file','$description')";
        $query_run = mysqli_query($connection,$query);
        if($query_run)
        {
            echo '<script type = "text/javascript">alert("Image Uploaded")</script>';
        }
        else{
            echo '<script type = "text/javascript">alert("Image Not Uploaded")</script>';
        }

    }
?>