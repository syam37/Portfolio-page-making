<?php 
    $con=mysqli_connect("localhost:3306","root","","loginsystem");
    $name=$_GET['name'];
    $select = mysqli_query($con,"delete from imageupload where name='$name' ");
    if($select)
    {
        echo '<script type = "text/javascript">alert("Record deleted successfully")</script>';
    }
    else{
        echo '<script type = "text/javascript">alert("Record not deleted")</script>';
    }
?>
<html>
    <head>
        <title> delete</title>
    </head>
    <center><a href="indexstore.html" class="logo"><strong> Back</strong></a></center>
</html>