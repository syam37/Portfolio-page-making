<!--Footer Starts Here-->
        <footer class="footer">
            <div class="wrapper">
                <p>
                    <a href="" title="RESUME" style="color:#E60026;">RESUME</a> &copy; <?php echo date('Y'); ?>. All Rights Reserved.    
                    Powered by <a href="https://search.yahoo.com/search?fr=mcafee&type=E211US826G0&p=vfstr" title="VIGNAN" target="_blank" style="color:#E60026;">VIGNAN</a>.
                </p>
            </div>
        </footer>
        <!--Footer Ends Here-->
</html>