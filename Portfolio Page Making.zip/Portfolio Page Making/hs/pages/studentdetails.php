<?php 
    include('check.php');
?>
<!--Body Starts Here-->
        <div class="main">
            <div class="content">
                <div class="studentdetails">
                    <?php 
                        if(isset($_SESSION['login']))
                        {
                            echo $_SESSION['login'];
                            unset($_SESSION['login']);
                        }
                        //Setting Time Limit Here
                      //  if(!isset($_SESSION['start_time']))
                        //{
                            //$_SESSION['start_time']=
                        //}
                    ?>
                    Hello <span class="heavy"><?php echo $_SESSION['student']; ?></span>
					. Welcome to Test Preparation Portal.<br />
                    
                    <div class="success">
                        <p style="text-align: left;">
                            Here you could view and modify your details.<br />
					    </p>
                    </div>
                    
                    <a href="<?php echo SITEURL; ?>index.php?page=update_studentt">
                        <button type="button" class="btn-go">YOUR PROFILE</button>
                    </a>
					
					 <a href="<?php echo SITEURL; ?>index.php?page=welcome">
                        <button type="button" class="btn-go">CLICK HERE TO TAKE YOUR EXAM</button>
                    </a>
					
                    <a href="<?php echo SITEURL; ?>index.php?page=logout">
                        <button type="button" class="btn-exit"> Quit </button>
                    </a>
                </div>
            </div>
        </div>
        <!--Body Ends Here-->