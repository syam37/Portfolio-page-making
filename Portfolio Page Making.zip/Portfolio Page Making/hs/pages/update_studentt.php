<!--Body Starts Here
PROFILE OF STUDENT-->
        <div class="main">
            <div class="content">
                <div class="report">
                    <h2>HI</h2><span class="heavy"><?php echo $_SESSION['student']; ?></span>
                           <h2>Here is your profile</h2>   
						   <h2>Click on update to modify your details</h2>
                    <?php                        
                        if(isset($_SESSION['update']))
                        {
                            echo $_SESSION['update'];
                            unset($_SESSION['update']);
                        }
                    ?>
                    <table>
                        <tr>
                            <th>Student ID</th>
                            <th>Full Name</th>
                            <th>Email</th>
							<th>Username</th>
                            <th>Contact</th>
                            <th>category</th>
                            <th>Actions</th>
                        </tr>
					
                    <!--Displaying Profile of particular student-->
                    <?php 
				        $tbl_name="tbl_student ORDER BY student_id";
                        $query=$obj->select_data($tbl_name);
                        $res=$obj->execute_query($conn,$query);
						$count_rows=$obj->num_rows($res);
                        if($count_rows>0)
                        {
                            while($row=$obj->fetch_data($res))
                            {
								$username=$row['username'];
								if($username==$_SESSION['student'])
								{   
										$student_id=$row['student_id'];
										$first_name=$row['first_name'];
										$last_name=$row['last_name'];
										$full_name=$first_name.' '.$last_name;
										$email=$row['email'];
										$username=$row['username'];
										$contact=$row['contact'];
										$category=$row['category'];
										?>
										<tr>
											<td><?php echo $student_id ?> </td>
											<td><?php echo $full_name; ?></td>
											<td><?php echo $email; ?></td>
											 <td><?php echo $username; ?></td>
											<td><?php echo $contact; ?></td>
											<td>
												<?php 
													//Get category Name from category_id
													$tbl_name2="tbl_category";
													$category_name=$obj->get_categoryname($tbl_name2,$category,$conn); 
													echo $category_name;
												?>
											</td>
											<td>
												<a href="<?php echo SITEURL; ?>index.php?page=update_profile&student_id=<?php echo $student_id; ?>"><button type="button" class="btn-update">UPDATE</button></a> 
													</td>
										</tr>
										
										<?php
								}
							}
							
							
                        }
                        else
                        {
                            echo "<tr><td colspan='7'><div class='error'>No DATA AVAILABLE.</div></tr></td>";
                        }
                    ?>
                        
                    </table>
					<a href="<?php echo SITEURL; ?>index.php?page=welcome">
                        <button type="button" class="btn-go">CLICK HERE TO TAKE YOUR EXAM</button>
                    </a>
                 <a href="<?php echo SITEURL; ?>index.php?page=logout">
                        <button type="button" class="btn-exit"> Quit </button>
                    </a>
				</div>
            </div>
        </div>
        <!--Body Ends Here-->