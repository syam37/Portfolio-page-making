<?php 
    define('SITEURL','http://localhost/hs/');
    define('LOCALHOST','localhost');
    define('USERNAME','root');
    define('PASSWORD','');
    define('DBNAME','loginsystem');
?>