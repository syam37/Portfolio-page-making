<!--Body Starts Here-->
        <div class="main">
            <div class="content">
                <div class="report">
                    <h2>category Manager</h2>
                    <a href="<?php echo SITEURL; ?>admin/index.php?page=add_category">
                        <button type="button" class="btn-add">Add category</button>
                    </a>
                    <?php 
                        if(isset($_SESSION['add']))
                        {
                            echo $_SESSION['add'];
                            unset($_SESSION['add']);
                        }
                        if(isset($_SESSION['update']))
                            {
                                echo $_SESSION['update'];
                                unset($_SESSION['update']);
                            }
                        if(isset($_SESSION['delete']))
                            {
                                echo $_SESSION['delete'];
                                unset($_SESSION['delete']);
                            }
                    ?>
                    
                    <table>
                        <tr>
                            <th>S.N.</th>
                            <th>category Title</th>
                            <th>Time Duration</th>
                            <th>Qns Per Exam</th>
                            <th>Is Active?</th>
                            <th>Actions</th>
                        </tr>
                        
                        <?php 
                            //Getting all the categories from database
                            $tbl_name="tbl_category ORDER BY category_id DESC";
                            $query=$obj->select_data($tbl_name);
                            $res=$obj->execute_query($conn,$query);
                            $count_rows=$obj->num_rows($res);
                            $sn=1;
                            if($count_rows>0)
                            {
                                while($row=$obj->fetch_data($res))
                                {
                                    $category_id=$row['category_id'];
                                    $category_name=$row['category_name'];
                                    $time_duration=$row['time_duration'];
                                    $qns_per_page=$row['qns_per_set'];
                                    $is_active=$row['is_active'];
                                    ?>
                                    <tr>
                                        <td><?php echo $sn++; ?>. </td>
                                        <td><?php echo $category_name; ?></td>
                                        <td><?php echo $time_duration; ?></td>
                                        <td><?php echo $qns_per_page; ?></td>
                                        <td><?php echo $is_active; ?></td>
                                        <td>
                                            <a href="<?php echo SITEURL; ?>admin/index.php?page=update_category&id=<?php echo $category_id; ?>"><button type="button" class="btn-update">UPDATE</button></a> 
                                            <a href="<?php echo SITEURL; ?>admin/pages/delete.php?id=<?php echo $category_id; ?>&page=categories"><button type="button" class="btn-delete" onclick="return confirm('Are you sure?')">DELETE</button></a>
                                        </td>
                                    </tr>
                                    <?php
                                }
                            }
                            else
                            {
                                echo "<tr><td colspan='6'><div class='error'>No categories added.</div></td></tr>";
                            }
                        ?>
                        
                        
                    </table>
                </div>
            </div>
        </div>
        <!--Body Ends Here-->