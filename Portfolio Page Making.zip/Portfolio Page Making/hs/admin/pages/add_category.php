<!--Body Starts Here-->
        <div class="main">
            <div class="content">
                <div class="report">
                    
                    <form method="post" action="" class="forms">
                        <h2>Add category</h2>
                        <?php 
                            if(isset($_SESSION['validation']))
                            {
                                echo $_SESSION['validation'];
                                unset($_SESSION['validation']);
                            }
                            if(isset($_SESSION['add']))
                            {
                                echo $_SESSION['add'];
                                unset($_SESSION['add']);
                            }
                        ?>
                        <span class="name">category Title</span> 
                        <input type="text" name="category_name" placeholder="category Title" required="true" /> <br />
                        
                        <span class="name">Time Duration</span>
                        <input type="text" name="time_duration" placeholder="Time Duration in Minutes" required="true" /><br />
                        
                        <span class="name">Questions/Set</span>
                        <input type="text" name="qns_per_page" placeholder="Total Questions Per Page" required="true" /><br />
                        
                        <span class="name">Total SQL Qns</span>
                        <input type="number" name="total_SQL_qns" placeholder="Total Number of SQL Questions" required="true" /><br />
                        
                        <span class="name">Total PHP Qns</span>
                        <input type="number" name="total_PHP_qns" placeholder="Total Number of PHP Questions" /><br />
                        
                        <span class="name">Is Active?</span>
                        <input type="radio" name="is_active" value="yes" /> Yes 
                        <input type="radio" name="is_active" value="no" /> No
                        <br />
                        
                        <input type="submit" name="submit" value="Add category" class="btn-add" style="margin-left: 15%;" />
                        <a href="<?php echo SITEURL; ?>admin/index.php?page=categories">
                            <button type="button" class="btn-delete">Cancel</button>
                        </a>
                    </form>
                    
                    <?php 
                        if(isset($_POST['submit']))
                        {
                            //echo "Clicked";
                            //Get Values froom the form
                            $category_name=$obj->sanitize($conn,$_POST['category_name']);
                            $time_duration=$obj->sanitize($conn,$_POST['time_duration']);
                            $qns_per_page=$obj->sanitize($conn,$_POST['qns_per_page']);
                            $total_SQL=$obj->sanitize($conn,$_POST['total_SQL_qns']);
                            $total_PHP=$obj->sanitize($conn,$_POST['total_PHP_qns']);
                            if(isset($_POST['is_active']))
                            {
                                $is_active=$obj->sanitize($conn,$_POST['is_active']);
                            }
                            else
                            {
                                $is_active="yes";
                            }
                            $added_date=date('Y-m-d');
                            
                            //Normal PHP Validation
                            if(($category_name=="")||($time_duration=="")||($qns_per_page==""))
                            {
                                $_SESSION['validation']="<div class='error'>category name or Time Duration or Question Per Page is Empty.</div>";
                                header('location:'.SITEURL.'admin/index.php?page=add_category');
                            }
                            //Inserting into the database
                            $tbl_name='tbl_category';
                            $data="category_name='$category_name',
                                    time_duration='$time_duration',
                                    qns_per_set='$qns_per_page',
                                    total_SQL='$total_SQL',
                                    total_PHP='$total_PHP',
                                    is_active='$is_active',
                                    added_date='$added_date',
                                    updated_date=''";
                            //Query to Insert Data
                            $query=$obj->insert_data($tbl_name,$data);
                            $res=$obj->execute_query($conn,$query);
                            if($res===true)
                            {
                                //Success Message
                                $_SESSION['add']="<div class='success'>New category successfully added.</div>";
                                header('location:'.SITEURL.'admin/index.php?page=categories');
                            }
                            else
                            {
                                //FAil Message
                                $_SESSION['add']="<div class='error'>Failed to add new category. Try again.</div>";
                                header('location:'.SITEURL.'admin/index.php?page=add_category');
                            }
                        }
                    ?>
                </div>
            </div>
        </div>
        <!--Body Ends Here-->